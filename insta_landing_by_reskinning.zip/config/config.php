<?php  
// ================================================================= //
// ================================================================= //
// =============== By MCh CPA 2021 : Re-skinning GRP =============== //
// ================================================================= //
// ================================================================= //

$uri = 'https://www.re-skinning.com/insta';
$wname = 'Free Instagram Followers'; 
$descrip = 'Free Ig Followers : Get free Instagram followers / get more instagram followers.';  

$cpa_link = 'https://cpalink.com';

?>